<?php
*******************************************************************/

$DOMAIN='localhost';
define('BASEURL',"http://$DOMAIN/REPO/services/f.e42.in/");
define('IMG_DIR',"media/$DOMAIN/images/");
define('IMG_PATH',BASEURL."media/$DOMAIN/images/");
define('LOG_FILE', "d:/".SITE_NAME.".".date("Y-m-d").".log");
 

/**********************************************************************/
/*                          db STUFF                                  */
/**********************************************************************/

define('DB_SERVER',"localhost");
define('DB_NAME',"fueltracker");
define('DB_USER',"fueltracker");
define('DB_PASSWORD',"fueltracker1233");

?>

